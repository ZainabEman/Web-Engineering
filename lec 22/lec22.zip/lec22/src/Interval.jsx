import React, { Component } from "react";

export class Interval extends Component {
  render() {
    return (
      <div>
        <p>Hello Zainab</p>
      </div>
    );
  }
}

export default Interval;
